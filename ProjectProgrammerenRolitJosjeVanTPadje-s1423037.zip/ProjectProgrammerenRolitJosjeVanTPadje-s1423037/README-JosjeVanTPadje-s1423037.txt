Dit is de README van de ROLIT van JOSJE VAN 'T PADJE - s1423037

ROLIT als stand alone game starten:
 stap 1 - RUN de Start Class
 stap 2 - Kies het aantal spelers waarmee u wilt spelen
 stap 3 - Klik op 'Start stand alone Game' om het spel te starten
		- U hoeft voor de stand alone versie van ROLIT geen IP adress, Poort, Player, naam of Strategy te kiezen.
 stap 4 - Speel het spel
	

Vraag een hint op:
 stap 1 - Start het spel zoals hier boven beschreven
 stap 2 - klik op de knop 'Hint' om een hint op te vragen
 stap 3 - De grijze velden die verschijnen zijn mogelijke opties
 stap 4 - Klik op een van de grijze velden om de gewenste zet te doen

Start een nieuw spel:
 stap 1 - Start het spel zoals hier boven beschreven
 stap 2 - Speel het spel
 stap 3 - Wanneer uw spel is afgelopen zal de knop knop 'New Game?' actief worden
 stap 4 - Klik op de knop 'New Game?'
 stap 5 - Ga verder vanaf stap 2 van "ROLIT als stand alone game starten" of stap 3 van "ROLIT als server game starten"
 

ROLIT als server game starten:
 stap 1 - RUN de Server Class
 stap 2 - Run de Start Class
 stap 3 - Voer een IP-adress en Poortnummer in
 stap 4 - Kies Human Player als u zelf wilt spelen
		- Voer een Naam in waarmee u wilt spelen
 stap 5 - Kies Computer Player als u de AI wilt laten spelen
		- Kies een Strategy
 stap 6 - Klink op 'Connect'
 stap 7 - De Server gaat connecten met de nieuwe client, verder gebeurt er nog niets, ik ben niet verder gekomen met het afmaken van de server
